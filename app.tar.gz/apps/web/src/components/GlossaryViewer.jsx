
import React from 'react';

/**
 * @deprecated This component has been removed as part of the glossary feature cleanup.
 * It is kept as a placeholder to prevent import errors during the transition.
 */
const GlossaryViewer = () => {
  return null;
};

export default GlossaryViewer;
