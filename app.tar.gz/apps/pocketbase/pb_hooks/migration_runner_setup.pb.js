/// <reference path="../pb_data/types.d.ts" />
// Migration Runner Setup Hook
// This initializes the migration system when PocketBase starts

// onBeforeServe((e) => {
//   console.log("Migration system initialized. Run migrations with: node apps/pocketbase/run_migrations.js");
//   e.next();
// });