/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("lessons");

  const record0 = new Record(collection);
    record0.set("course_id", "pbc_9676646180");
    record0.set("title", "Implementation and Transition");
    record0.set("description", "Master implementation strategies, understand transition approaches, develop implementation plans, and ensure successful adoption of lease accounting standards.");
    record0.set("order", 8);
    record0.set("duration", 60);
    record0.set("content_type", "text");
  app.save(record0);
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})
