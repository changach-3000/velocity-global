/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("lessons");

  const record0 = new Record(collection);
    record0.set("course_id", "pbc_9676646180");
    record0.set("title", "Lessor Classification and Accounting");
    record0.set("description", "Master lessor lease classification, understand finance and operating lease accounting, develop lessor accounting skills, and apply lessor accounting to leases.");
    record0.set("order", 6);
    record0.set("duration", 60);
    record0.set("content_type", "text");
  app.save(record0);

  const record1 = new Record(collection);
    record1.set("course_id", "pbc_9676646180");
    record1.set("title", "Implementation and Transition");
    record1.set("description", "Master ASC 842 implementation strategies, understand transition approaches, develop implementation plans, and ensure successful adoption.");
    record1.set("order", 7);
    record1.set("duration", 60);
    record1.set("content_type", "text");
  app.save(record1);

  const record2 = new Record(collection);
    record2.set("course_id", "pbc_9676646180");
    record2.set("title", "Practical Expedients and Special Topics");
    record2.set("description", "Master practical expedients available under ASC 842, understand special lease accounting topics, develop knowledge of simplification options, and apply practical expedients to leases.");
    record2.set("order", 8);
    record2.set("duration", 30);
    record2.set("content_type", "text");
  app.save(record2);
}, (app) => {
  // Rollback: record IDs not known, manual cleanup needed
})
